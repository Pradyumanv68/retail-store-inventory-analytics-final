"""Streamlit dashboard:  streamlit run dashboard/app.py"""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import numpy as np
import pandas as pd
import plotly.express as px
import streamlit as st

from src import analytics

st.set_page_config(page_title="Retail Sales & Inventory Analytics", page_icon="📦", layout="wide")
px.defaults.template = "plotly_dark"
px.defaults.color_discrete_sequence = ["#FF4B4B", "#2E7BE0", "#2ca02c", "#f2c811", "#9467bd"]
RISK_COLORS = {"Critical": "#d62728", "High Risk": "#ff7f0e", "Medium": "#f2c811", "Healthy": "#2ca02c", "Overstock": "#1f77b4"}
RISK_ORDER = list(RISK_COLORS)


@st.cache_data(show_spinner="Preparing data (first run only)...")
def load():
    if not (ROOT / "reports" / "inventory_actions.csv").exists():
        import run_pipeline
        run_pipeline.main()
    df = pd.read_csv(ROOT / "data" / "processed" / "clean.csv.gz", parse_dates=["date"])
    return (df, pd.read_csv(ROOT / "reports" / "inventory_actions.csv"),
            pd.read_csv(ROOT / "reports" / "model_metrics.csv"),
            pd.read_csv(ROOT / "reports" / "forecast_next_7_days.csv", parse_dates=["date"]))


df, actions, mets, fc = load()

st.sidebar.title("📦 Filters")
stores = st.sidebar.multiselect("Store", sorted(df["store_id"].unique()), default=sorted(df["store_id"].unique()))
cats = st.sidebar.multiselect("Category", sorted(df["category"].unique()), default=sorted(df["category"].unique()))
d0, d1 = st.sidebar.date_input("Date range", (df["date"].min().date(), df["date"].max().date()))
f = df[df["store_id"].isin(stores) & df["category"].isin(cats) & df["date"].between(pd.Timestamp(d0), pd.Timestamp(d1))]
a = actions[actions["store_id"].isin(stores) & actions["category"].isin(cats)]
if f.empty:
    st.warning("No data for the selected filters."); st.stop()

st.title("📦 Retail Store Sales & Inventory Performance")
st.caption(f"{len(f):,} records selected · {f['date'].min():%d %b %Y} – {f['date'].max():%d %b %Y} · "
           "historical sales → demand forecast → inventory risk → replenishment action")
t1, t2, t3, t4, t5 = st.tabs(["Executive Overview", "Inventory Analytics", "Sales Analytics", "Forecast & Actions", "Data"])

with t1:
    k = analytics.kpis(f)
    c = st.columns(6)
    c[0].metric("Total Revenue", f"${k['total_revenue']/1e6:,.2f}M")
    c[1].metric("Units Sold", f"{k['total_units']:,}")
    c[2].metric("Inventory (latest day)", f"{k['current_inventory']:,}")
    c[3].metric("Avg Revenue / Txn", f"${k['avg_revenue_per_txn']:,.0f}")
    c[4].metric("Inventory Turnover (annual)", f"{k['inventory_turnover']:.1f}x")
    c[5].metric("Stockout Rate", f"{k['stockout_rate_pct']:.1f}%")
    c2 = st.columns(5)
    n_crit = int(a["risk"].isin(["Critical", "High Risk"]).sum())
    c2[0].metric("Critical / High-risk items", n_crit, f"{n_crit / max(len(a), 1) * 100:.0f}% of store-products", delta_color="inverse")
    c2[1].metric("Overstocked items", int((a["risk"] == "Overstock").sum()))
    c2[2].metric("Forecast demand (next 7 days)", f"{a['forecast_7d'].sum():,.0f} units")
    c2[3].metric("Units to reorder", f"{a['recommended_order'].sum():,.0f}")
    c2[4].metric("Unmet demand (lost sales)", f"{k['unmet_demand_pct']:.1f}%", f"${k['lost_revenue']/1e6:,.2f}M revenue lost", delta_color="inverse")
    m = analytics.monthly_sales(f)
    st.plotly_chart(px.line(m, x="date", y="revenue", markers=True, title="Monthly Revenue Trend"), width="stretch")
    l, r = st.columns(2)
    l.plotly_chart(px.bar(analytics.revenue_by(f, "category"), x="category", y="revenue", title="Revenue by Category"), width="stretch")
    r.plotly_chart(px.bar(analytics.revenue_by(f, "store_id"), x="store_id", y="revenue", title="Revenue by Store"), width="stretch")
    top = analytics.revenue_by(f, "product_id").head(10)
    st.plotly_chart(px.bar(top, x="revenue", y="product_id", orientation="h", title="Top 10 Products by Revenue").update_yaxes(autorange="reversed"), width="stretch")

with t2:
    counts = a["risk"].value_counts().reindex(RISK_ORDER).fillna(0).reset_index()
    counts.columns = ["risk", "pairs"]
    l, r = st.columns(2)
    l.plotly_chart(px.bar(counts, x="risk", y="pairs", color="risk", color_discrete_map=RISK_COLORS, title="Inventory Risk Distribution"), width="stretch")
    mv = a["movement"].value_counts().reset_index(); mv.columns = ["movement", "pairs"]
    r.plotly_chart(px.pie(mv, names="movement", values="pairs", hole=.45, title="Fast / Slow Movers"), width="stretch")
    hm = a.pivot(index="product_id", columns="store_id", values="days_of_cover").clip(upper=60)
    st.plotly_chart(px.imshow(hm, color_continuous_scale="RdYlGn", aspect="auto", text_auto=".0f", title="Days of Cover Heatmap (red = stockout risk, capped at 60)"), width="stretch")
    inv = f.groupby("category")["inventory_level"].mean().reset_index()
    st.plotly_chart(px.bar(inv, x="category", y="inventory_level", title="Average Inventory Level by Category"), width="stretch")
    cols = ["store_id", "product_id", "category", "current_inventory", "avg_daily_demand", "days_of_cover", "risk", "movement"]
    st.subheader("🚨 Critical / High-risk items"); st.dataframe(a[a["risk"].isin(["Critical", "High Risk"])][cols].round(1), width="stretch", hide_index=True)
    st.subheader("📉 Overstock & dead-stock items"); st.dataframe(a[(a["risk"] == "Overstock") | (a["movement"] == "Dead Stock")][cols].round(1), width="stretch", hide_index=True)

with t3:
    daily = f.groupby("date")[["revenue", "units_sold"]].sum().rolling(7).mean().reset_index()
    st.plotly_chart(px.line(daily, x="date", y=["revenue", "units_sold"], title="7-day Rolling Revenue & Units", facet_row="variable").update_yaxes(matches=None), width="stretch")
    l, r = st.columns(2)
    pr = f.groupby("holiday_promotion")["units_sold"].mean().reset_index()
    pr["holiday_promotion"] = pr["holiday_promotion"].map({0: "No promotion", 1: "Promotion"})
    l.plotly_chart(px.bar(pr, x="holiday_promotion", y="units_sold", title="Avg Units Sold: Promotion vs None"), width="stretch")
    ds = f.groupby("discount_pct").agg(units=("units_sold", "mean"), revenue=("revenue", "mean")).reset_index()
    r.plotly_chart(px.line(ds, x="discount_pct", y=["units", "revenue"], markers=True, title="Discount % vs Avg Units / Revenue"), width="stretch")
    l, r = st.columns(2)
    l.plotly_chart(px.bar(f.groupby("seasonality")["units_sold"].mean().reset_index(), x="seasonality", y="units_sold", title="Avg Units Sold by Season"), width="stretch")
    dow = f.groupby("day_of_week")["units_sold"].mean().reset_index()
    dow["day"] = dow["day_of_week"].map(dict(enumerate(["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"])))
    r.plotly_chart(px.bar(dow, x="day", y="units_sold", title="Avg Units Sold by Day of Week"), width="stretch")

with t4:
    best = mets.loc[mets["best"], "Model"].iat[0]
    st.subheader(f"Model comparison - best: {best}")
    st.dataframe(mets.drop(columns="best"), width="stretch", hide_index=True)
    st.caption("Time-based split: trained on history, tested on the final 90 days. Lower MAE/RMSE/MAPE and higher R² are better.")
    hist = f[f["date"] > f["date"].max() - pd.Timedelta(days=60)].groupby("date")["demand_target"].sum().reset_index()
    fsel = fc[fc["store_id"].isin(stores) & fc.merge(df.drop_duplicates(["store_id", "product_id"])[["store_id", "product_id", "category"]], on=["store_id", "product_id"])["category"].isin(cats).values]
    fdaily = fsel.groupby("date")["predicted_units"].sum().reset_index()
    fig = px.line(hist, x="date", y="demand_target", title="Daily demand: last 60 days (actual) + next 7 days (forecast)")
    fig.add_scatter(x=fdaily["date"], y=fdaily["predicted_units"], mode="lines+markers", name="forecast", line=dict(color="#d62728", dash="dash"))
    st.plotly_chart(fig, width="stretch")

    st.subheader("🤖 Replenishment recommendations")
    show = a[a["recommended_order"] > 0].head(10)
    for _, r in show.iterrows():
        (st.error if r["risk"] in ("Critical", "High Risk") else st.warning)(r["action"])
    for _, r in a[a["risk"] == "Overstock"].head(3).iterrows():
        st.info(r["action"])
    st.download_button("⬇️ Download full action queue (CSV)", a.to_csv(index=False).encode(), "inventory_actions.csv", "text/csv")

    st.subheader("🧮 Order calculator")
    c = st.columns(4)
    s_id = c[0].selectbox("Store", sorted(actions["store_id"].unique()))
    p_id = c[1].selectbox("Product", sorted(actions["product_id"].unique()))
    lead = c[2].slider("Lead time (days)", 1, 14, 3)
    svc = c[3].select_slider("Service level", [0.90, 0.95, 0.975, 0.99], 0.95)
    row = actions[(actions["store_id"] == s_id) & (actions["product_id"] == p_id)].iloc[0]
    z = {0.90: 1.28, 0.95: 1.65, 0.975: 1.96, 0.99: 2.33}[svc]
    ss = np.ceil(z * row["std_daily_demand"] * np.sqrt(lead))
    order = max(0, np.ceil(row["forecast_7d"] + ss - row["current_inventory"]))
    q = st.columns(4)
    q[0].metric("Current inventory", f"{row['current_inventory']:.0f}")
    q[1].metric("Predicted 7-day demand", f"{row['forecast_7d']:.0f}")
    q[2].metric("Safety stock", f"{ss:.0f}")
    q[3].metric("Recommended order", f"{order:.0f}", help="forecast + safety stock - current inventory")

with t5:
    st.subheader("Filtered data")
    st.dataframe(f.drop(columns=["units_outlier"]).tail(2000), width="stretch", hide_index=True)
    st.caption("Showing the most recent 2,000 filtered rows. Download the full filtered set below.")
    st.download_button("⬇️ Download filtered data (CSV)", f.to_csv(index=False).encode(), "filtered_retail_data.csv", "text/csv")
